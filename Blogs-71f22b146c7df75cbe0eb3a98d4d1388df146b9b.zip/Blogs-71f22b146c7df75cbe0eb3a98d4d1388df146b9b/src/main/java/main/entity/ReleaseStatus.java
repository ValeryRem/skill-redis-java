package main.entity;

public enum ReleaseStatus {
    INACTIVE, PUBLISHED, PENDING, DECLINED
}
