package main.entity;

public enum ModerationStatus {
    NEW, ACCEPTED, DECLINED
}
