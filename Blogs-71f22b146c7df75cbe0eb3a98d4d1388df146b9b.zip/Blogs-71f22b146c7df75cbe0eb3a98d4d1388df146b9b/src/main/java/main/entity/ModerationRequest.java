package main.entity;

public enum ModerationRequest {
    ACCEPT, DECLINE
}
